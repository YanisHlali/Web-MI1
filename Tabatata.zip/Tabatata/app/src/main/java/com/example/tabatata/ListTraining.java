package com.example.tabatata;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.room.Room;

import com.example.tabatata.db.AppDatabase;
import com.example.tabatata.db.Training;
import com.example.tabatata.db.TrainingDao;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ListTraining extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_training);
        getSupportActionBar().hide();
        displayTraining();
    }

    public void displayTraining() {
        AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "training").build();
        TrainingDao trainingDao = db.taskDao();
        List<Training> test = new List<Training>() {
            @Override
            public int size() {
                return 0;
            }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public boolean contains(@Nullable Object o) {
                return false;
            }

            @NonNull
            @Override
            public Iterator<Training> iterator() {
                return null;
            }

            @NonNull
            @Override
            public Object[] toArray() {
                return new Object[0];
            }

            @NonNull
            @Override
            public <T> T[] toArray(@NonNull T[] ts) {
                return null;
            }

            @Override
            public boolean add(Training training) {
                return false;
            }

            @Override
            public boolean remove(@Nullable Object o) {
                return false;
            }

            @Override
            public boolean containsAll(@NonNull Collection<?> collection) {
                return false;
            }

            @Override
            public boolean addAll(@NonNull Collection<? extends Training> collection) {
                return false;
            }

            @Override
            public boolean addAll(int i, @NonNull Collection<? extends Training> collection) {
                return false;
            }

            @Override
            public boolean removeAll(@NonNull Collection<?> collection) {
                return false;
            }

            @Override
            public boolean retainAll(@NonNull Collection<?> collection) {
                return false;
            }

            @Override
            public void clear() {

            }

            @Override
            public Training get(int i) {
                return null;
            }

            @Override
            public Training set(int i, Training training) {
                return null;
            }

            @Override
            public void add(int i, Training training) {

            }

            @Override
            public Training remove(int i) {
                return null;
            }

            @Override
            public int indexOf(@Nullable Object o) {
                return 0;
            }

            @Override
            public int lastIndexOf(@Nullable Object o) {
                return 0;
            }

            @NonNull
            @Override
            public ListIterator<Training> listIterator() {
                return null;
            }

            @NonNull
            @Override
            public ListIterator<Training> listIterator(int i) {
                return null;
            }

            @NonNull
            @Override
            public List<Training> subList(int i, int i1) {
                return null;
            }
        };
        Executor myExecutor = Executors.newSingleThreadExecutor();
        myExecutor.execute(() -> {
            List<Training> trainings = db.taskDao().getAll();
            int trainingsLength = trainings.size();
            for (int i = 0; i < trainingsLength; i++) {
                test.add(trainings.get(i));
            }
        });
        createTextView(test);
    }

    public void createTextView (List<Training> trainings) {
        int width = getWindowManager().getDefaultDisplay().getWidth();

        int trainingsLength = trainings.size();
        ConstraintLayout constraintLayout = findViewById(R.id.list_training);
        for (int i = 0; i < 100; i++) {
            TextView textView = new TextView(this);
            textView.setTextSize(28);
            textView.setTextColor(Integer.parseInt("FFFFFF", 16)+0xFF000000);
            textView.setGravity(Gravity.CENTER);
            textView.setText(" · Entrainement n°" + (i+1) + " · ");
            textView.setPaddingRelative(0, 400+(i*200), 100, 0);
            constraintLayout.addView(textView);
        }
    }
}